package com.example.flutter_bluetooth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
